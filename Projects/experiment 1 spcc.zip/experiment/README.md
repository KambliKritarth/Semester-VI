To compile program:

```
$ gcc -Wall -o experiment single_pass.c
```

To run program:

```
$ ./experiment 
```